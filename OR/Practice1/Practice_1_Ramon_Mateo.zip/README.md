# README

* Before start execution need to download the VOCdevkit. And unzip on the main folder where main.py is found. 

* If you have linux before start the execution you need to uncomment the line **50** in utils.py and comment the line **49**. Else if you have windows you don't need to uncomment and comment anything