# Resum Paper Rules SEL

Si el nombre d'atributs és $n_a$

