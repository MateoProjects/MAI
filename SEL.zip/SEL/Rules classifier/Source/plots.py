import matplotlib.pyplot as plt


def plotLen(lenDataX, lenDataY, name):
    # plot the length of the data
    plt.plot(lenDataX, lenDataY)
    plt.savefig(name)
    #plt.show()    