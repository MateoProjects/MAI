import pandas as pd
import numpy as np
dictBalance = {"L": 0, "B": 1, "R":2}
dataReplace = []





def preprocessBalance():
    data = pd.read_csv('data/balance-scale.data', header=None)
    for i in range(len(data)):
        key = data[0][i]
        dataReplace.append(dictBalance[key])
    data[0] = dataReplace
    data.to_csv('data/preprocessed_balance.csv', index=False, header=False)

