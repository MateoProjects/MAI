def generateCombinations(list1, list2, type):
    """_
    Generates a combinations of two lists
    @param list1: list
    @param list2: list
    @return: list of combinations
    """
    combinations = []
    for i in list1:
        for j in list2:
            if type == "str":
                combinations.append([i, j])
            else:
                combinations.append([int(i), int(j)])
    return combinations


def generateCombinationsDouble(list1, list2, list3, list4, type):
    combinations = []
    for i in list1:
        for j in list2:
            for m in list3:
                for n in list4:
                    if type == "str":
                        combinations.append([i, j, m, n])
                    else:
                        combinations.append([int(i), int(j), int(m), int(n)])

    return combinations


def pairOfValue(uniqueValues: list, type="str"):

    pairOfValues = []
    for i in range(len(uniqueValues)):
        for j in range(i+1, len(uniqueValues)):
            for k in generateCombinations(uniqueValues[i], uniqueValues[j], type):
                pairOfValues.append((i, j, k))

    return pairOfValues


def twoInOneRule(uniqueValues: list, type="str"):
    # combine two rules in one
    pairOfRules = []
    for i in range(len(uniqueValues)):
        for j in range(i+1, len(uniqueValues)):
            for m in range(j+1, len(uniqueValues)):
                for n in range(m + 1, len(uniqueValues)):
                    for k in generateCombinationsDouble(uniqueValues[i], uniqueValues[j], uniqueValues[m], uniqueValues[n], type):
                        pairOfRules.append((i, j, m, n, k))

    return pairOfRules
